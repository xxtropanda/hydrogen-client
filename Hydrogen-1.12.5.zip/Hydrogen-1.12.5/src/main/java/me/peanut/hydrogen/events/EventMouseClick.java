package me.peanut.hydrogen.events;

import com.darkmagician6.eventapi.events.Event;

/**
 * Created by peanut on 26/07/2021
 */
public class EventMouseClick implements Event {
}
