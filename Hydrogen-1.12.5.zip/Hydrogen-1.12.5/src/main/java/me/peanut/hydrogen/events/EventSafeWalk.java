package me.peanut.hydrogen.events;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

/**
 * Created by peanut on 07/02/2021
 */
public class EventSafeWalk extends EventCancellable implements Event {

}
