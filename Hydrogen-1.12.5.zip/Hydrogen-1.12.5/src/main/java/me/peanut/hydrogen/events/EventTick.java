package me.peanut.hydrogen.events;

import com.darkmagician6.eventapi.events.Event;

/**
 * Created by peanut on 21/02/2021
 */
public class EventTick implements Event {
}
