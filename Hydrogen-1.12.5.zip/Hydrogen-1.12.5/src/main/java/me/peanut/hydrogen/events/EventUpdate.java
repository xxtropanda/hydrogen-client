package me.peanut.hydrogen.events;

import com.darkmagician6.eventapi.events.Event;

public class EventUpdate implements Event {
}
