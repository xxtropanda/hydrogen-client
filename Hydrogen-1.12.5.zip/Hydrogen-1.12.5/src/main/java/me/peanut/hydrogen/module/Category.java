package me.peanut.hydrogen.module;

public enum Category {

    Combat,
    Movement,
    Render,
    Player,
    Gui,
    Hud

}
