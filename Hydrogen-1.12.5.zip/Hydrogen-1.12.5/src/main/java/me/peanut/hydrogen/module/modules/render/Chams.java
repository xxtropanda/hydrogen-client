package me.peanut.hydrogen.module.modules.render;

import org.lwjgl.input.Keyboard;
import me.peanut.hydrogen.module.Category;
import me.peanut.hydrogen.module.Info;
import me.peanut.hydrogen.module.Module;

@Info(name = "Chams", description = "Draws models through walls", category = Category.Render)
public class Chams extends Module {
    public Chams() {}
}
