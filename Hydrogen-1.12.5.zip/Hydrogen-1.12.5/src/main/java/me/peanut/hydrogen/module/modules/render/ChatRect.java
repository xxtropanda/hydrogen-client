package me.peanut.hydrogen.module.modules.render;

import me.peanut.hydrogen.module.Category;
import me.peanut.hydrogen.module.Info;
import me.peanut.hydrogen.module.Module;

/**
 * Created by peanut on 28/07/2021
 */
@Info(name = "NoChatRect", category = Category.Render, description = "Removes the chat background")
public class ChatRect extends Module {

    public ChatRect() {}

}
