package me.peanut.hydrogen.module.modules.render;

import me.peanut.hydrogen.module.Category;
import me.peanut.hydrogen.module.Info;
import me.peanut.hydrogen.module.Module;

/**
 * Created by peanut on 19/01/2022
 */
@Info(name = "HitAnimation", description = "Changes your hit animation (german client XD)", category = Category.Render)
public class HitAnimation extends Module {
}
