package me.peanut.hydrogen.module.modules.render;

import org.lwjgl.input.Keyboard;
import me.peanut.hydrogen.module.Category;
import me.peanut.hydrogen.module.Info;
import me.peanut.hydrogen.module.Module;

/**
 * Created by peanut on 10/02/2021
 */
@Info(name = "NoSpeedFOV", description = "Removes FOV gained by speed effects", category = Category.Render)
public class NoSpeedFOV extends Module {
    public NoSpeedFOV() {}
}
