package me.peanut.hydrogen.ui.ingame.style;

public interface Style {

    void drawArrayList();

    void drawInfo();

    void drawPotionEffects();

    void drawWatermark();

    void drawHotbar();


}
